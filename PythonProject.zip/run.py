from ext import app
from routes import *

app.run(host="0.0.0.0")